﻿using System;
using System.Collections.Generic;


namespace MVOP_Ukol_2 {

    class Program {

        static void Main(string[] args) {

            Player player = new Player();

            //remove the comments below to test your strategies.
            PlayerStrategy[] strategies = { 
             //new ExampleStrategy(),                   // 0 points
            //new RandomStrategy(),                    // 2 points
             //new NoDuplicateRandomStrategy(),         // 2 points
                new LinearStrategy(),                    // 2 points
            
             // new LinearHuntingStrategy(),             // 2 points
            // new NoDuplicateRandomHuntingStrategy(),  // 2 points
            // new DitheredHuntingStrategy(),           // 2 points
             
            // new WeightedHuntingStrategy()            // 3 points
            // new CustomStrategy()                     // 1-3 points
            };
            float[] strategyResults = new float[strategies.Length];
            int gameCount = 300;
            int mapSize   = 10;
            int howManyBeforeAfterGamesToOutput = 2;    //the program will output the BEFORE/AFTER state of the map for each strategy
                                                        //change this variable to see more or less of the games

            for (int i = 0; i < strategies.Length; i++) {

                player.ChangeStrategy(strategies[i]);
                Console.WriteLine(new string('-', ($"Testing {strategies[i].GetType().Name}:  \\/\\/").Length));
                Console.WriteLine($"Testing {strategies[i].GetType().Name}:  \\/\\/");
                Console.WriteLine();
                strategyResults[i] = player.TestStrategy(gameCount, howManyBeforeAfterGamesToOutput,mapSize);

            }

            Console.WriteLine(new string('-', 52));
            Console.WriteLine($"Strategy performance results after {gameCount} games:  \\/\\/\n");

            for (int i = 0; i < strategies.Length; i++) {
                Console.WriteLine(i == 0 ? ' ' : '-');
                Console.WriteLine($"Average number of {strategies[i].GetType().Name} moves per game: {strategyResults[i]}");
            }

            Console.ReadKey();
        }
    }
}

   