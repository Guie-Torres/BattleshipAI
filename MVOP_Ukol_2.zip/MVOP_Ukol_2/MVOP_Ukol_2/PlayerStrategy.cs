﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace MVOP_Ukol_2 {

    /// <summary>
    /// Abstract class can not be instantiated. This servers only as a reference what ALL the other strategies look like. (What methods or variables they must have)
    /// </summary>
    public abstract class PlayerStrategy {
        public abstract void Initialize();
        public abstract void MakeAMove(Map map);
    }

    /// <summary>
    /// This is an example how your strategies should be implemented. 
    /// </summary>
    public class ExampleStrategy : PlayerStrategy {

        int myVariable;

        // Every strategy is initialized at the beginning of each game
        public override void Initialize() {
            myVariable = 3;


        }

        //This is the method that will be called every time you have to make a move.
        public override void MakeAMove(Map map) {
            
            if (CanIShootHere(myVariable, map)) {
                map.Shoot(myVariable, myVariable);                      // map.Shoot(Y,X) will shoot at the given [Y,X] position
            }
            //Console.WriteLine(map);                                     //I can use this to write the game board to the console each round

        }

        // You can and should create helping methods
        private bool CanIShootHere(int num, Map map) {

            // map.Look(Y,X) will give me either Tile.miss or Tile.hit or Tile.unkown 
            if (map.Look(myVariable, myVariable) == Tile.unknown)
                return true;
            else
                return false;
        }


    }

    //This strategy should shoot randomly.
    public class RandomStrategy : PlayerStrategy {

        Random r;

        public override void Initialize() {
            //Runs once at the start

           r = new Random();
        }

        public override void MakeAMove(Map map) {
            //Runs every round

            int x = r.Next(0, map.size);
            int y = r.Next(0, map.size);

            map.Shoot(y, x);
        }
    }

    //This strategy should shoot randomly, but only where it hasn't shot at before.
    public class NoDuplicateRandomStrategy : PlayerStrategy {
        Random r;
        public override void Initialize() {
            r = new Random();
        }

        public override void MakeAMove(Map map) {

            int x;
            int y;

            do
            {
                x = r.Next(0, map.size);
                y = r.Next(0, map.size);
            } while (map.Look(y, x) != Tile.unknown);

            map.Shoot(y, x);
            
        }
    }

    //This strategy should sequentially shoot at every tile starting (for example) at the top left corner, going to the right and then the next row.
    public class LinearStrategy : PlayerStrategy {

        int x;
        int y;
        public override void Initialize() {
            x = 0;
            y = 0;
        }

        public override void MakeAMove(Map map) {

            map.Shoot(y, x);

            x++;

            if(x >= map.size)
            {
                x = 0;
                y++;
            }

        }
    }

    //This strategy should shoot sequentially from top left to bottom, but when it hits a ship, it should be shooting (hunting) near that hit untill it sinks a ship.
    public class LinearHuntingStrategy : PlayerStrategy {
        
        int x;
        int y;

        List<int> xList;
        List<int> yList;
        public override void Initialize()
        {
            xList = new List<int>();
            yList = new List<int>();
            
            x = 0;
            y = 0;
        }

        public override void MakeAMove(Map map)
        {
            if (xList.Count > 0)
                Hunt(map);
            else
                Linear(map);
        }

        void Linear(Map map)
        {
            bool shot = false;

            //Avoids shooting at already shot tiles
            if (map.Look(y, x) == Tile.unknown)
            {
                shot = true;
                
                 if (map.Shoot(y, x) == Result.hit)
                    AddToHunt(y, x);
            }

            if (map.Shoot(y, x) == Result.hit)
                AddToHunt(y, x);

            x++;

            if (x >= map.size)
            {
                x = 0;
                y++;
            }

            if (!shot)
                Linear(map);
        }

        void Hunt(Map map)
        {
            int length = xList.Count;

            for (int i = 0; i < length; i++)
            {
                if (!map.WithinBounds(yList[i], xList[i]))
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
                else if (map.Look(yList[i], xList[i]) != Tile.unknown)
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
            }

            if(xList.Count <= 0)
            {
                Linear(map);
                return;
            }

            if(map.Shoot(yList[0], xList[0]) == Result.hit)
            {
                AddToHunt(yList[0], xList[0]);
            }

            xList.RemoveAt(0);
            yList.RemoveAt(0);
        }

        void AddToHunt(int y, int x)
        {
            xList.Add(x);
            xList.Add(x + 1);
            xList.Add(x);
            xList.Add(x - 1);

            yList.Add(y + 1);
            yList.Add(y);
            yList.Add(y - 1);
            yList.Add(y);
        }
    }
    //This strategy should shoot randomly, but when it hits a ship, it should be shooting (hunting) near that hit untill it sinks a ship.
    public class NoDuplicateRandomHuntingStrategy : PlayerStrategy {
  
        List<int> xList;
        List<int> yList;

        Random r;
        public override void Initialize() {
            xList = new List<int>();
            yList = new List<int>();

            r = new Random();
        }

        public override void MakeAMove(Map map) {

            if (xList.Count > 0)
                Hunt(map);
            else
                Random(map);

        }

        void Random(Map map)
        {
            int x;
            int y;

            do
            {
                x = r.Next(0, map.size);
                y = r.Next(0, map.size);
            } while (map.Look(y, x) != Tile.unknown);

            if (map.Shoot(y, x) == Result.hit)
                AddToHunt(y, x);
        }

        void Hunt(Map map)
        {
            int length = xList.Count;

            for (int i = 0; i < length; i++)
            {
                if (!map.WithinBounds(yList[i], xList[i]))
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
                else if (map.Look(yList[i], xList[i]) != Tile.unknown)
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
            }

            if (xList.Count <= 0)
            {
                Random(map);
                return;
            }

            if (map.Shoot(yList[0], xList[0]) == Result.hit)
            {
                AddToHunt(yList[0], xList[0]);
            }

            xList.RemoveAt(0);
            yList.RemoveAt(0);
        }

        void AddToHunt(int y, int x)
        {
            xList.Add(x);
            xList.Add(x + 1);
            xList.Add(x);
            xList.Add(x - 1);

            yList.Add(y + 1);
            yList.Add(y);
            yList.Add(y - 1);
            yList.Add(y);
        }
    }

    //This strategy should shoot sequentially from top left to bottom, but only every other tile and when it hits a ship, it should be shooting (hunting) near that hit untill it sinks a ship.
    public class DitheredHuntingStrategy : PlayerStrategy {

        int x;
        int y;

        List<int> xList;
        List<int> yList;
        public override void Initialize()
        {
            xList = new List<int>();
            yList = new List<int>();

            x = 0;
            y = 0;
        }

        public override void MakeAMove(Map map)
        {
            if (xList.Count > 0)
                Hunt(map);
            else
                Linear(map);
        }

        void Linear(Map map)
        {
            bool shot = false;

            if (map.Look(y, x) == Tile.unknown)
            {
                shot = true;
                
                if (map.Shoot(y, x) == Result.hit)
                    AddToHunt(y, x);
            }

            x += 2;

            if (x >= map.size)
            {
                y++;
                x = 0 + y % 2;

                if (y == 10)
                    y = 0;
            }

            if (!shot)
                Linear(map);
        }

        void Hunt(Map map)
        {
            int length = xList.Count;

            for (int i = 0; i < length; i++)
            {
                if (!map.WithinBounds(yList[i], xList[i]))
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
                else if (map.Look(yList[i], xList[i]) != Tile.unknown)
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
            }

            if (xList.Count <= 0)
            {
                Linear(map);
                return;
            }


            if (map.Shoot(yList[0], xList[0]) == Result.hit)
            {
                AddToHunt(yList[0], xList[0]);
            }

            xList.RemoveAt(0);
            yList.RemoveAt(0);
        }

        void AddToHunt(int y, int x)
        {
            xList.Add(x);
            xList.Add(x + 1);
            xList.Add(x);
            xList.Add(x - 1);

            yList.Add(y + 1);
            yList.Add(y);
            yList.Add(y - 1);
            yList.Add(y);
        }

    }

    //This strategy should consider the probability of any ship being at every tile of the map. Then pick the one with the highest probability and hunt the ship if it hits something.
    public class WeightedHuntingStrategy : PlayerStrategy {

        int[] numOfShips;
        int[,] possibleShips;

        List<int> xList;
        List<int> yList;

        public override void Initialize() {
            numOfShips = new int[] { 1, 2, 1, 1 };
            possibleShips = new int[10, 10];

            xList = new List<int>();
            yList = new List<int>();
        }
        public override void MakeAMove(Map map) {
            if (xList.Count > 0)
                Hunt(map);
            else
                Weighted(map);        
        }

        void Weighted(Map map)
        {

            //Calculate probabilities
            for (int i = 2; i < 6; i++)
            {
                if (numOfShips[i - 2] <= 0)
                    continue;

                for (int j = 0; j < map.size; j++)
                {
                    for (int k = 0; k < map.size; k++)
                    {
                        for (int l = 1; l < 5; l++)
                        {
                            if (map.CheckForAvailability(j, k, i, (Direction)l))
                                possibleShips[j, k]++;
                        }
                    }
                }
            }

            int highestX = 0;
            int highestY = 0;

            //Find highest chance
            for (int i = 0; i < map.size; i++)
            {
                for (int j = 0; j < map.size; j++)
                {
                    if (possibleShips[i, j] > possibleShips[highestY, highestX])
                    {
                        highestX = j;
                        highestY = i;
                    }
                }
            }

            //Shoot at highest and calculate result
            switch (map.Shoot(highestY, highestX))
            {
                case (Result)3: numOfShips[0]--; break;
                case (Result)4: case (Result)5: numOfShips[1]--; break;
                case (Result)6: numOfShips[2]--; break;
                case (Result)7: numOfShips[3]--; break;

                case Result.hit: AddToHunt(highestY, highestX); break;
            }
        }

        void Hunt(Map map)
        {
            int length = xList.Count;

            for (int i = 0; i < length; i++)
            {
                if (!map.WithinBounds(yList[i], xList[i]))
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
                else if (map.Look(yList[i], xList[i]) != Tile.unknown)
                {
                    xList.RemoveAt(i);
                    yList.RemoveAt(i);

                    i--;
                    length -= 1;
                }
            }

            if (xList.Count <= 0)
            {
                Weighted(map);
                return;
            }


            if (map.Shoot(yList[0], xList[0]) == Result.hit)
            {
                AddToHunt(yList[0], xList[0]);
            }

            xList.RemoveAt(0);
            yList.RemoveAt(0);
        }

        void AddToHunt(int y, int x)
        {
            xList.Add(x);
            xList.Add(x + 1);
            xList.Add(x);
            xList.Add(x - 1);

            yList.Add(y + 1);
            yList.Add(y);
            yList.Add(y - 1);
            yList.Add(y);
        }
    }

    //Do whatever 
    public class CustomStrategy : PlayerStrategy {

        public override void Initialize() {
            //todo:
        }
        public override void MakeAMove(Map map) {
            //todo:
        }
    }

}
